"""Testy metod analizy wibracji przejścia. Uruchom: python -m unittest discover -s tests"""
import datetime
import unittest

from app import (
    analiza_wibracji_przejscia,
    generuj_profil_urodzenia,
)


class TestAnalizaWibracjiPrzejscia(unittest.TestCase):
    def test_metoda1_zero_gdy_wibracje_dat_sa_rowne(self):
        wynik = analiza_wibracji_przejscia(
            datetime.date(1970, 5, 12), datetime.date(2016, 8, 24)
        )
        self.assertEqual(wynik["wibracja_urodzenia"], 7)
        self.assertEqual(wynik["wibracja_smierci"], 5)
        self.assertEqual(wynik["roznica"], 2)
        self.assertFalse(wynik["metoda1_zero"])

    def test_metoda2_zero_dla_warunku_9_9(self):
        wynik = analiza_wibracji_przejscia(
            datetime.date(1980, 9, 27), datetime.date(2016, 9, 27)
        )
        self.assertEqual(wynik["rok_osobisty"], 9)
        self.assertEqual(wynik["wibracja_dnia_miesiaca_smierci"], 9)
        self.assertTrue(wynik["metoda2_zero"])
        self.assertEqual(wynik["metoda2_wynik"], 0)
        self.assertTrue(wynik["gmar_tikkun"])

    def test_metoda2_nie_zwroci_zera_bez_9_9(self):
        wynik = analiza_wibracji_przejscia(
            datetime.date(1970, 5, 12), datetime.date(2016, 8, 24)
        )
        self.assertFalse(wynik["metoda2_zero"])
        self.assertIsNone(wynik["metoda2_wynik"])

    def test_brak_analizy_gdy_smierc_przed_urodzeniem(self):
        self.assertIsNone(analiza_wibracji_przejscia(
            datetime.date(2016, 8, 24), datetime.date(1970, 5, 12)
        ))

    def test_profil_urodzenia_nadal_ma_dotychczasowa_redukcje(self):
        profil = generuj_profil_urodzenia(12, 5, 1970)
        self.assertTrue(all(1 <= wartosc <= 22 for wartosc in profil.values()))


if __name__ == "__main__":
    unittest.main()
